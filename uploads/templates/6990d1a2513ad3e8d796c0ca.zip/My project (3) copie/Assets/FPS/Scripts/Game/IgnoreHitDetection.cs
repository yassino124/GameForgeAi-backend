﻿using UnityEngine;

namespace Unity.FPS.Game
{
    public class IgnoreHitDetection : MonoBehaviour
    {
    }
}