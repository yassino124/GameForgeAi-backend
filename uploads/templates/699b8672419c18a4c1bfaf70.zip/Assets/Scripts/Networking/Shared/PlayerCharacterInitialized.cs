using Unity.Entities;

namespace Unity.MP_FPS
{
    public struct PlayerCharacterInitialized : IComponentData, IEnableableComponent
    {
    }
}